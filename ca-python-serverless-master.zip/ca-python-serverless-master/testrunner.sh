#!/bin/bash

cd tests/todo/api

echo "Running all tests in tests/todo/api"
python -m unittest discover